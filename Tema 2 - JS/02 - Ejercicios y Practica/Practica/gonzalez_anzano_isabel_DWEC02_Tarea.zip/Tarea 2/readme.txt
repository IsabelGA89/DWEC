Notas sobre las prácticas:
#Práctica 1:
Se ha integrado bootstrap para mejorar la visibilidad y sea más sencilla la corrección del ejercicio.

#Práctica 2:
A la hora de introducir valores será necesario tener en cuenta que:
- no se pueden dejar vacíos los campos.
- los días irán de entre 1 y 31.
- los meses entre 1 y 12.
- y el año deberá ser menos al 2020.