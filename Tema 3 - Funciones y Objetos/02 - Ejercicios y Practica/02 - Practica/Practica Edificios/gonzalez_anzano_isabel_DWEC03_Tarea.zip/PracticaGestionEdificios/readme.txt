=> He utilizado Arrays para el tratamiento de los datos de cada edidificio porque me ha parecido que era la manera
más sencilla de actualizar y mantener el código.

 edificioA = [planta][puerta]

También me planteé el crear un array por cada edificio con un objeto planta con sus puertas y propietarios siguiendo esta estructura:

edificioA = [
{planta:0, puertas:[puerta][propietario]},
{planta:1, puertas:[puerta][propietario]}
]

Pero el desarrollo era mucho más complejo.

Por este motivo, el código está desarrollado en base a arrays.


=> También he añadido algún extra al ejercicio propuesto, como en los métodos getters, añadiendo una opción de extraer
el contenido ya con un texto formateado o sólo el resultado de la variable y algunas comprobaciones adicionales, pero que me han
parecido interesantes.
